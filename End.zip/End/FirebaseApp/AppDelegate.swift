//
//  AppDelegate.swift
//  FirebaseApp
//
//  Created by Robert Canton on 2018-02-02.
//  Copyright © 2018 Robert Canton. All rights reserved.
//

import UIKit
import Firebase

let primaryColor = UIColor(red: 210/255, green: 109/255, blue: 180/255, alpha: 1)
let secondaryColor = UIColor(red: 52/255, green: 148/255, blue: 230/255, alpha: 1)

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        FirebaseApp.configure()
        // Override point for customization after application launch.
        
        let authListener = Auth.auth().addStateDidChangeListener { auth, user in
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            if user != nil {
                
                UserService.observeUserProfile(user!.uid) { userProfile in
                    UserService.currentUserProfile = userProfile
                }
                //
                let controller = storyboard.instantiateViewController(withIdentifier: "MainTabBarController") as! UITabBarController
                self.window?.rootViewController = controller
                self.window?.makeKeyAndVisible()
            } else {
                
                
                UserService.currentUserProfile = nil
                
                // menu screen
                let controller = storyboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
                self.window?.rootViewController = controller
                self.window?.makeKeyAndVisible()
            }
        }
        
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Отправляется, когда приложение собирается перейти из активного в неактивное состояние. Это может происходить при определенных типах временных прерываний (таких как входящий телефонный звонок или SMS-сообщение) или когда пользователь выходит из приложения и начинает переход в фоновое состояние.
        // Используйте этот метод для приостановки текущих задач, отключения таймеров и аннулирования обратных вызовов рендеринга графики. Игры должны использовать этот метод, чтобы приостановить игру.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Используйте этот метод для освобождения общих ресурсов, сохранения пользовательских данных, аннулирования таймеров и сохранения достаточного количества информации о состоянии приложения, чтобы восстановить ваше текущее состояние в случае, если оно будет прекращено позднее.
        // Если ваше приложение поддерживает фоновое выполнение, этот метод вызывается вместо applicationWillTerminate: когда пользователь завершает работу.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Вызывается как часть перехода из фона в активное состояние; здесь вы можете отменить многие изменения, внесенные при входе в фон.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Перезапустите все задачи, которые были приостановлены (или еще не запущены), когда приложение было неактивно. Если приложение ранее было в фоновом режиме, при необходимости обновите пользовательский интерфейс.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Вызывается, когда приложение собирается завершить работу. Сохраните данные, если это необходимо. Смотрите также applicationDidEnterBackground :.
    }


}

